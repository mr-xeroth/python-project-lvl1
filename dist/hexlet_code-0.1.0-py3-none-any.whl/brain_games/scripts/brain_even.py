#!/usr/bin/env python3
import prompt
from ..cli import welcome_user
from random import seed, randint

def main():
    print('Welcome to the Brain Games!')
    userName = welcome_user()
    print('Answer "yes" if the number is even, otherwise answer "no".')

    answerCount = 3
    seed(None)

    while answerCount:
        randNumber = randint(0,20)
        
        if randNumber % 2:
            oddNumber = True
        else: 
            oddNumber = False
        
        print(f'Question: {randNumber}')
        
        strAnswer = ""
        while not(strAnswer == 'yes' or strAnswer == 'no'):
            strAnswer = prompt.string('Your answer: ').casefold()
        
        boolCorrect = False
        if not(oddNumber) and strAnswer == 'yes':
            boolCorrect = True
        elif oddNumber and strAnswer == 'no':
            boolCorrect = True
        else:
            strReply = "'{}' is wrong answer ;(. Correct answer was '{}'."
            if oddNumber:
                print(strReply.format('yes', 'no'))
            else:
                print(strReply.format('no', 'yes'))
            print(f"Let's try again, {userName}!")
            quit()
        if boolCorrect:
            print('Correct!')
            answerCount -= 1
    print(f'Congratulations, {userName}!')

if __name__ == '__main__':
    main()

