#!/usr/bin/env python3
import prompt
from ..cli import welcome_user
from random import seed, randint


def answerValidate(oddNumber, strAnswer):
    if not(oddNumber) and strAnswer == 'yes':
        return True
    elif oddNumber and strAnswer == 'no':
        return True
    return False


def notifyAndQuit():
    nonlocal oddNumber
    nonlocal userName
    strReply = "'{}' is wrong answer ;(. Correct answer was '{}'."
    if oddNumber:
        print(strReply.format('yes', 'no'))
    else:
        print(strReply.format('no', 'yes'))
    print(f"Let's try again, {userName}!")
    quit()


def main():
    print('Welcome to the Brain Games!')
    userName = welcome_user()
    print('Answer "yes" if the number is even, otherwise answer "no".')
    answerCount = 3
    seed(None)

    while answerCount:
        randNumber = randint(0, 20)
        oddNumber = False
        if randNumber % 2:
            oddNumber = True
        print(f'Question: {randNumber}')
        strAnswer = ""
        while not(strAnswer == 'yes' or strAnswer == 'no'):
            strAnswer = prompt.string('Your answer: ').casefold()
        boolCorrect = answerValidate(oddNumber, strAnswer)
        if boolCorrect:
            print('Correct!')
            answerCount -= 1
        else:
            notifyAndQuit()
    print(f'Congratulations, {userName}!')


if __name__ == '__main__':
    main()
